package com.BugTracker.Controller;

import org.springframework.stereotype.Controller;


@Controller
public class DevloperController {


	
}
